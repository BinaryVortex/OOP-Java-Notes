/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.accountproject;

/**
 *
 * @author b.villarini
 */
public class AccountProject {

    public static void main(String[] args) {
        System.out.println("Hello World!");
        
        Account account1 = new Account(); 
        
        Account account2 = new Account(300);
        
        System.out.println("the balance in account 1 " + account1.getBalance());
        
        System.out.println("the balance in account 2 " + account2.getBalance());
        
        account1.deposit(1000);
        
        account1.joinAccount(account2);
        
        System.out.println("new account 1 baalnce " + account1.getBalance());
        
    }
}
