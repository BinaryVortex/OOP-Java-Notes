/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.accountproject;

/**
 *
 * @author b.villarini
 */
public class Account {
    
    // properties attributes -> INSTANCE VARIABLES
    private double balance;
    private String accNumber;
    
    // constructor
    public Account(){
        balance = 0;
        accNumber = "A0";
        
    }
    
    public Account(double initialBalance){
        balance = initialBalance;
    }
    
    
    // BEHAVIOUR -> INSTANCE METHODS
    
    public void withdraw(double amount){
       // balance = balance - amount;
        balance -= amount;
        
    }
    
    public void deposit(double amount){
        balance += amount;
    }
    
    public double getBalance(){
        return balance;
        
    }
    
    public void close(){
        balance =0;
    }
    
    public void joinAccount(Account accountToJoin){
        balance += accountToJoin.getBalance();
        accountToJoin.close();
        
    }
    
    
}
